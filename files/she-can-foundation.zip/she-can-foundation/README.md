# She Can Foundation – Webpage

A fully responsive, interactive single-page website for She Can Foundation.

## 📁 Project Structure

```
she-can-foundation/
├── index.html   ← Main webpage
├── style.css    ← All styles (dark mode, responsive, animations)
├── script.js    ← JavaScript features
└── README.md    ← This file
```

## 🚀 How to Run

### Option 1 – Just open the file (simplest)
Double-click `index.html` — it opens directly in your browser. Done!

### Option 2 – Live Server (recommended for development)
If you have VS Code installed:
1. Install the **Live Server** extension
2. Right-click `index.html` → **Open with Live Server**

### Option 3 – Python local server
```bash
cd she-can-foundation
python3 -m http.server 3000
# Then open http://localhost:3000 in your browser
```

### Option 4 – Node.js server
```bash
cd she-can-foundation
npx serve .
# Then open the URL shown in your terminal
```

---

## ✨ Features Included

| Feature | Details |
|---|---|
| **NGO Name** | "She Can Foundation" in nav & footer |
| **Heading** | Hero: *"Every girl deserves a future she chooses."* |
| **About Section** | Two-column layout with mission & pillars |
| **Image** | Hero photo of young women studying |
| **Button** | "Be Part of the Change" → modal; "Get Involved Today" |
| **Footer** | Brand, nav links, copyright |
| **Dark Mode** | Toggle button, persists via localStorage |
| **Animations** | Fade-up on load, scroll reveal, counter animation |
| **Responsive** | Mobile, tablet, desktop breakpoints |
| **Interactive UI** | Modal overlay, stat counters, hover effects |
| **Accessibility** | Reduced motion respected, keyboard ESC closes modal |

---

No build tools or npm install required. Pure HTML + CSS + JS.
